Team Name: RCB

Team Members:
Jeet Khimani (002115111)
Het Shah (001563170)
Kapil Kadge (002987899)

Project Name: QuizIt

Project Description:

-QuizIt is a web app where you can take assess your knowledge by taking quiz on different topics with different difficulty level. As soon as you pass the quiz, you can generate your certificate from the web app itself.

-For starting, you need to create an account on the website. After logging in you can see and take all the quiz. You can keep track of your previous quiz results in the history panel. You can update your information and also delete the account. This fulfill's the CRUD requirement of the project. 

-We are planning to add lecture notes of several topics in the end for user's preparation.

-There would some fun quiz too.;)

Front-end Technologies: HTML, CSS, SASS, Javascript, Angular

Back-end Technology: Node.js


Database: MongoDB


