module.exports = {
    mongo: 'mongodb://localhost:27017/quizitdb'
}